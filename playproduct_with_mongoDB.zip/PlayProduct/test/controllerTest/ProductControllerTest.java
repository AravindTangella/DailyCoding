package controllerTest;

import controllers.ProductController;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.test.WithApplication;
import org.junit.Test;
import static org.junit.Assert.*;
import static play.test.Helpers.contentAsString;


public class ProductControllerTest extends WithApplication {

    ProductController pc = new ProductController();

    @Override
    protected Application provideApplication() {
        return new GuiceApplicationBuilder().build();
    }

    public void insertData() {
        assertEquals("Product added successfully\n"+"Product\n\tId : "+5+"\n\tName : "+"AC"+"\n\tPrice : "+12000.0
                +"\n\tRating : "+3.7, contentAsString(pc.create(5, "AC", 12000, 3.7)));

        assertEquals("Product added successfully\n"+"Product\n\tId : "+10+"\n\tName : "+"Macbook air M1"+"\n\tPrice : "+84990.0
                +"\n\tRating : "+4.7, contentAsString(pc.create(10, "Macbook air M1",84990.0 , 4.7)));

        assertEquals("Product added successfully\n"+"Product\n\tId : "+15+"\n\tName : "+"Sofa"+"\n\tPrice : "+5890.0
                +"\n\tRating : "+4.1, contentAsString(pc.create(15, "Sofa", 5890, 4.1)));

        assertEquals("Product added successfully\n"+"Product\n\tId : "+20+"\n\tName : "+"Office chair"+"\n\tPrice : "+4890.27
                +"\n\tRating : "+4.2, contentAsString(pc.create(20, "Office chair", 4890.27, 4.2)));
    }

    @Test
    public void createTest() {
        insertData();
    }

    @Test
    public void retrieveTest() {
        insertData();

        assertEquals("Product\n\tId : "+20+"\n\tName : "+"Office chair"+"\n\tPrice : "+4890.27
                +"\n\tRating : "+4.2, contentAsString(pc.retrieve(20)));

        assertEquals("No product with id "+22, contentAsString(pc.retrieve(22)));
    }

    @Test
    public void updateTest() {
        insertData();

        assertEquals("Product updated successfully\n"+"Product\n\tId : "+5+"\n\tName : "+"AC"+"\n\tPrice : "+15789.0
                +"\n\tRating : "+4.2, contentAsString(pc.update(5, "AC", 15789, 4.2)));

        assertEquals("Product updated successfully\n"+"Product\n\tId : "+10+"\n\tName : "+"Macbook air M1"+"\n\tPrice : "+82000.0
                +"\n\tRating : "+4.6, contentAsString(pc.update(10, "Macbook air M1", 82000, 4.6)));

        assertEquals("No product with id "+34, contentAsString(pc.update(34, "Sony LCD TV", 43780, 4.3)));
    }

    @Test
    public void deleteTest() {
        insertData();

        assertEquals("No product with id "+507, contentAsString(pc.delete(507)));

        assertEquals("No product with id "+404, contentAsString(pc.delete(404)));

        assertEquals("Product deleted successfully", contentAsString(pc.delete(5)));

        assertEquals("Product deleted successfully", contentAsString(pc.delete(20)));
    }

}
