#!/usr/bin/env bash
if [ -f ${PROJECT_HOME}/RUNNING_PID ]; then
  source ${APP_HOME}/stop-server.sh
fi

${PROJECT_HOME} -Dplay.http.secret.key=crypto-secret -Dconfig.file=${APP_HOME}/buildproperties/application.conf