package controllers;
import play.mvc.*;


import javax.inject.Inject;

import model.ProductBase;

public class ProductController extends Controller {

    ProductBase productBase;
    @Inject
    public ProductController() {
        productBase = new ProductBase();
    }

    public Result  create(int id, String name, double price, double rating) {
        return ok(productBase.addProduct(id, name, price, rating));
    }

    public Result retrieve(int id) {
        return ok(productBase.getProduct(id));
    }

    public Result update(int id, String name, double price, double rating) {
        boolean isUpdated = productBase.updateProduct(id, name, price, rating);

        return isUpdated == true ? ok("Product updated successfully\n"+productBase.getProduct(id)) :
                                    ok("No product with id "+id);
    }

    public Result delete(int id) {
        boolean isDeleted = productBase.deleteProduct(id);

        return isDeleted == true ? ok("Product deleted successfully") : ok("No product with id "+id);
    }
}


