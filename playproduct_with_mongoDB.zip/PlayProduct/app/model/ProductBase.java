package model;

import java.util.*;
import java.util.logging.Filter;


import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import com.mongodb.client.model.Updates;
public class ProductBase {

    MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017/?serverSelectionTimeoutMS=5000&connectTimeoutMS=10000&3t.uriVersion=3&3t.connection.name=Products&3t.alwaysShowAuthDB=true&3t.alwaysShowDBFromUserRole=true"));

    public String  addProduct(int id, String name, double price, double rating) {
        System.out.println("creating product");
        MongoCollection<Document> mongoCollection = mongoClient.getDatabase("CRM").getCollection("products");

        Document document = new Document();
        document.put("id", id);
        document.put("name", name);
        document.put("price", price);
        document.put("rating", rating);

        mongoCollection.insertOne(document);
        System.out.println("Inserted");
        return mongoCollection.find(Filters.eq("id", id)).first().toJson();
    }

    public String getProduct(int id) {
        MongoCollection<Document> mongoCollection = mongoClient.getDatabase("CRM").getCollection("products");

        Document document  =  mongoCollection.find(Filters.eq("id", id)).first();

        if(document == null)
            return "No product with id: "+id;
        return document.toJson();
    }

    public boolean updateProduct(int id, String name, double price, double rating) {
        MongoCollection<Document> mongoCollection = mongoClient.getDatabase("CRM").getCollection("products");

        if(mongoCollection.find(Filters.eq("id", id)).first() == null)
            return false;

        mongoCollection.updateOne(Filters.eq("id" , id), Updates.set("name", name));
        mongoCollection.updateOne(Filters.eq("id" , id), Updates.set("price", price));
        mongoCollection.updateOne(Filters.eq("id" , id), Updates.set("rating", rating));
        return true;
    }

    public boolean deleteProduct(int id) {
        MongoCollection<Document> mongoCollection = mongoClient.getDatabase("CRM").getCollection("products");

        if(mongoCollection.find(Filters.eq("id", id)).first() == null)
            return false;

        mongoCollection.deleteMany(Filters.eq("id", id));
        return true;
    }
}
