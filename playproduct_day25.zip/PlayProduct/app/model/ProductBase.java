package model;

import java.util.*;

public class ProductBase {
    Map<Integer, Product> products = new HashMap<>();

    public String  addProduct(int id, String name, double price, double rating) {
        products.put(id, new Product(id, name, price, rating));
        return "Product added successfully\n"+getProduct(id);
    }

    public String getProduct(int id) {
        if(products.get(id) != null) {
            Product product = products.get(id);
            return "Product\n\tId : "+product.getId()+"\n\tName : "+product.getName()+"\n\tPrice : "+product.getPrice()
                    +"\n\tRating : "+product.getRating();
        }
        return "No product with id "+id;
    }

    public boolean updateProduct(int id, String name, double price, double rating) {
        if(products.get(id) != null) {
            products.put(id, new Product(id, name, price, rating));
            return true;
        }
        return false;
    }

    public boolean deleteProduct(int id) {
        if(products.get(id) != null) {
            products.remove(id);
            return true;
        }
        return false;
    }
}
