package model;

import java.util.*;

public class Product {
    int id;
    String name;
    double price;
    double rating;

    public Product(int id, String name, double price, double rating) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
    public double getRating() {
        return rating;
    }

    public String toString() {
        return "id : "+id+" name : "+name+" price : "+price+" rating : "+rating;
    }
}