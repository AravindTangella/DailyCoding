package model;

import java.util.Arrays;
import java.util.*;

import com.mongodb.BulkWriteResult;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.BulkWriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.InsertOneModel;
import com.mongodb.client.model.Updates;
import org.bson.Document;

public class HomeMode {
    public static void main(String[] args) {
        MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017/?serverSelectionTimeoutMS=5000&connectTimeoutMS=10000&3t.uriVersion=3&3t.connection.name=Products&3t.alwaysShowAuthDB=true&3t.alwaysShowDBFromUserRole=true"));

        MongoCollection<Document> mongoCollection = mongoClient.getDatabase("CRM").getCollection("products");

        mongoCollection.updateOne(Filters.eq("id" , 15), Updates.set("rating", 3.4));
        mongoCollection.updateOne(Filters.eq("id" , 15), Updates.set("price", 3456));

        mongoCollection.deleteMany(Filters.eq("id", 15));



        MongoCursor<Document> cursor = mongoCollection.find().cursor();



        while (cursor.hasNext()) {
            Document document = cursor.next();
            System.out.println(document.toJson());
        }
    }
}
